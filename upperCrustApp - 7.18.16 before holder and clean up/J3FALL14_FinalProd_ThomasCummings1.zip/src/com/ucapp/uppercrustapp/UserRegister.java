//****************************************************
//Author:       Thomas Cummings
//Date Created: 12-9-14
//Class:        CIST 2373 - Java III
//Project:      Production Exam
//Title:        Upper Crust final
//Description:  Android app, Ordering system 
//****************************************************

package com.ucapp.uppercrustapp;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Build;

public class UserRegister extends ActionBarActivity {
	
	//variables 
	//android types
	EditText e_mail;
	EditText fName;
	EditText lName;
	CheckBox email_chk;
	CheckBox text_chk;
	CheckBox both_chk;
	String alert_type = "Alert me by: ";
	boolean isAlert = false;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE); //Remove action bar from screen
		setContentView(R.layout.activity_user_register);
		//get EditText field data by id name
		e_mail = (EditText)findViewById(R.id.emailTxt);
		fName = (EditText)findViewById(R.id.firstNameTxt);
		lName = (EditText)findViewById(R.id.lastNameTxt);
		email_chk = (CheckBox)findViewById(R.id.checkBox_email);
		text_chk = (CheckBox)findViewById(R.id.checkBox_text);
		both_chk = (CheckBox)findViewById(R.id.checkBox_both);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_register, menu);
		return true;
	}

	// code to change activity with BTN click (back to login)
	public void returnToMain(View v)
	{
		finish();
	}
	//submit data for registration 
	public void registerUser(View v)
	{
		// change EditText type to String type
		String email = e_mail.getText().toString();
		String first_name = fName.getText().toString();
		String last_name = lName.getText().toString();
		//set alert type method call
		setAlertType();
		// check if text fields are empty and if checkBoxes are checked
		if(first_name.isEmpty() || last_name.isEmpty() || email.isEmpty() || (!text_chk.isChecked() &&
				!email_chk.isChecked() && !both_chk.isChecked()))
		{
			if(first_name.isEmpty() && last_name.isEmpty() && email.isEmpty())
			{
				Toast.makeText(this, "All fields are required", Toast.LENGTH_LONG).show();
			}
			else if(first_name.isEmpty() && last_name.isEmpty())
			{
				Toast.makeText(this, "First name is empty\nLast name is empty", Toast.LENGTH_LONG).show();
			}
			else if(first_name.isEmpty() && email.isEmpty())
			{
				Toast.makeText(this, "First name is empty\nEmail is empty", Toast.LENGTH_LONG).show();
			}
			else if(last_name.isEmpty() && email.isEmpty())
			{
				Toast.makeText(this, "Last name is empty\nEmail is empty", Toast.LENGTH_LONG).show();
			}
			else if(first_name.isEmpty())
			{
				Toast.makeText(this, "First name is empty", Toast.LENGTH_LONG).show();
			}
			else if(last_name.isEmpty())
			{
				Toast.makeText(this, "Last name is empty", Toast.LENGTH_LONG).show();
			}
			else if(email.isEmpty())
			{
				Toast.makeText(this, "Email is empty", Toast.LENGTH_LONG).show();
			}
			else if(!text_chk.isChecked() && !email_chk.isChecked() && !both_chk.isChecked())
			{
				Toast.makeText(this, "You must have atleast one alert type", Toast.LENGTH_LONG).show();
			}
		}//end if text fields are empty and if checkBoxes are checked
		//test to see if email is a valid @student.wiregeass.edu or @wiregrass.edu
		else if(email.contains("@student.wiregrass.edu") || email.contains("@wiregrass.edu") && isAlert)
		{
			Toast toast = Toast.makeText(this, "Check Wiregrass email for confrimation\n" + alert_type, Toast.LENGTH_LONG);
			toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);//positioning Toast at Center of the Mobile Screen
    		toast.show();
			// register user (send info to database)
			
			// return to login activity
			Intent i = new Intent(UserRegister.this, MainActivity.class);
			// set the new task and clear flags
			i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
	        startActivity(i);
		}
		else
		{
			Toast.makeText(this, "Must be a valid wiregrass email", Toast.LENGTH_LONG).show();
		}
	}//end register user method
	public boolean setAlertType()
	{
		if(text_chk.isChecked())
		{
			//Toast.makeText(this, "Text message", Toast.LENGTH_LONG).show();
			alert_type += "Text message";
			isAlert = true;
		}
		if(email_chk.isChecked())
		{
			//Toast.makeText(this, "Email message", Toast.LENGTH_LONG).show();
			alert_type += "Email message";
			isAlert = true;
		}
		if(both_chk.isChecked() || (text_chk.isChecked() && email_chk.isChecked()))
		{
			//Toast.makeText(this, "Both Text message and Email message", Toast.LENGTH_LONG).show();
			alert_type += "Both Text message and Email message";
			isAlert = true;
		}
		return isAlert;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}//end user register activity
